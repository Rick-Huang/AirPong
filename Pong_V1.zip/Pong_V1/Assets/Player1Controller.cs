﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using System.Text;

public class Player1Controller : MonoBehaviour {

    public KeyCode moveUp = KeyCode.W;
    public KeyCode moveDown = KeyCode.S;
    public KeyCode moveLeft = KeyCode.A;
    public KeyCode moveRight = KeyCode.D;
    public float speed = 10.0f;
    public float boundY = 2.25f;
    private Rigidbody2D rb2d;
    public TextAsset txtFile;
    private int count = 0;



    void ConvertInput(){
        string[] input = txtFile.text.Split('\n');

        FileStream fs = new FileStream("input.txt", FileMode.Open, FileAccess.Read);

        var pos = transform.position;
        if(count>input.Length-1){
            count = 0;
        }

        string[] fields = input[count].Split(',');
        int x_field = int.Parse(fields[0]);
        int y_field = int.Parse(fields[1]);

        if(x_field == -1 || y_field ==-1){
             pos.x = -4;
             pos.y = 0;
           }
        else{
             pos.x = (float)(x_field / 150.0 - 5);
             pos.y = (float)(y_field / 100.0 - 2.5);
            }
        if (pos.y > boundY)
        {
            pos.y = boundY;
        }
        else if (pos.y < -boundY)
        {
            pos.y = -boundY;
        }
        if (pos.x < -5)
        {
            pos.x = -5;
        }
        else if (pos.x > -1)
        {
            pos.x = -1;
        }
        transform.position = pos;
        //Debug.Log(pos.y);
        count++;
        /*while (!inp_stm.EndOfStream)
        {
            string inp_ln = inp_stm.ReadLine();
            if (inp_ln == "None"){
                pos.x = -4;
                pos.y = 0;
            }
            else {
                string x = inp_ln.Substring(1, inp_ln.IndexOf(','));
                string y = inp_ln.Substring(inp_ln.IndexOf(' ')+1, inp_ln.IndexOf(')'));
                ///int x_convert = Int32.Parse(x);    ///need a proper way to convert from string to 
                ///int y_convert = Int32.Parse(y);
                int x_convert = 0;
                int y_convert = 0;
                for (int i = 0; i <x.Length;i++){
                    x_convert = x_convert * 10 + x[i];
                }

                for (int i = 0; i < y.Length; i++)
                {
                    y_convert = y_convert * 10 + y[i];
                }
                pos.x = (float)(x_convert / 150.0 - 5);
                pos.y = (float)(y_convert / 100.0 - 2.5);
                Console.WriteLine("x: {0}\t y: {1}\t", pos.x, pos.y);


            }*/
        }



	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();

	}

    void Update()
    {
       /* var vel = rb2d.velocity;
        if (Input.GetKey(moveUp))
        {
            vel.y = speed;
        }
        else if (Input.GetKey(moveDown))
        {
            vel.y = -speed;
        }
        else if (Input.GetKey(moveLeft))
        {
            vel.x = -speed;
        }
        else if (Input.GetKey(moveRight))
        {
            vel.x = speed;
        }
        else
        {
            vel.y = 0;
            vel.x = 0;
        }
        rb2d.velocity = vel;

        var pos = transform.position;
        if (pos.y > boundY)
        {
            pos.y = boundY;
        }
        else if (pos.y < -boundY)
        {
            pos.y = -boundY;
        }
        else if (pos.x > 5)
        {
            pos.x = 5;
        }
        else if (pos.x < 1)
        {
            pos.x = 1;
        }
        transform.position = pos;
    }*/
    ConvertInput();

    }

}
